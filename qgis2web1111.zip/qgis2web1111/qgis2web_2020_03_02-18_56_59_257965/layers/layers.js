var wms_layers = [];


        var lyr_Linnentown_0 = new ol.layer.Tile({
            'title': 'Linnentown',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://api.mapbox.com/styles/v1/jengallucci/ck73muwit0ztu1iqky6y9ncvr/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiamVuZ2FsbHVjY2kiLCJhIjoiY2s2Y2tiemNmMWQxMjNocGJtMHp2cGt5aSJ9.JM83dA3Vw05Filx3nhMORw'
            })
        });

lyr_Linnentown_0.setVisible(true);
var layersList = [lyr_Linnentown_0];
