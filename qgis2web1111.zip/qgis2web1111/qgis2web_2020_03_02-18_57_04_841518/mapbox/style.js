
var styleJSON = {
    "version": 8,
    "name": "qgis2web export",
    "pitch": 0,
    "light": {
        "intensity": 0.2
    },
    "sources": {
        "Linnentown_0": {
            "type": "raster",
            "tiles": ["https://api.mapbox.com/styles/v1/jengallucci/ck73muwit0ztu1iqky6y9ncvr/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiamVuZ2FsbHVjY2kiLCJhIjoiY2s2Y2tiemNmMWQxMjNocGJtMHp2cGt5aSJ9.JM83dA3Vw05Filx3nhMORw"],
            "tileSize": 256
        }},
    "sprite": "",
    "glyphs": "https://glfonts.lukasmartinelli.ch/fonts/{fontstack}/{range}.pbf",
    "layers": [
        {
            "id": "background",
            "type": "background",
            "layout": {},
            "paint": {
                "background-color": "#ffffff"
            }
        },
        {
            "id": "lyr_Linnentown_0_0",
            "type": "raster",
            "source": "Linnentown_0"
        }],
}